import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { CssBaseline } from '@material-ui/core';
import Header from './components/Header';
import PlaceToVisit from './components/PlaceToVisit';
import ReactPlayer from 'react-player';

const useStyles = makeStyles((theme) => ({
  root: {

    // height: '100%',
    // width : '100%',
    position:"absolute",
    left:'50%',
    top:'50%',
    objectFit:"cover",
    transform:"translate(-50%,-50%)",
    zIndex:'-99',
    // background:'black',
    // opacity:1,
    
    


    // backgroundImage: `url(${process.env.PUBLIC_URL + '/assets/bg.jpg'})`,
    // backgroundRepeat: 'no-repeat',
    // backgroundSize: 'cover',

      },
}));
export default function App() {
  const classes = useStyles();
  return (
    <div >
          <ReactPlayer playing={true}   className={classes.root} width="100%" height="auto"  muted={true} url="https://media.istockphoto.com/videos/tropical-heaven-video-id473382233" onEnded="https://media.istockphoto.com/videos/big-teahopoo-wave-breaking-and-splashing-video-id515504730"
 />
 
          
          
      <CssBaseline />
      <Header />
      <PlaceToVisit />
    </div>
  );
}  
